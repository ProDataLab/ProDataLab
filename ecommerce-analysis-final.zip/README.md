# 🛒 E-commerce Data Analysis Project

This project explores an **E-commerce dataset** to identify business problems and solve them with **data-driven insights**.

## 📊 Problem Statement
The E-commerce company faces:
1. Low repeat purchase rate.
2. High cart abandonment.
3. Imbalanced sales across categories.
4. Poor revenue forecasting.

## 🚀 Objectives
- Analyze customer purchase patterns.
- Identify best-selling and least-performing categories.
- Segment customers (loyal vs. one-time buyers).
- Predict revenue trends.
- Provide actionable solutions.

## 📂 Files
- `analysis.ipynb` → Complete Jupyter Notebook Analysis
- `dataset.csv` → Sample Ecommerce Data
- `report.md` → Problem solving write-up
- `index.html` → GitHub Pages front-end

## 🌐 View Project
Enable **GitHub Pages** in repo settings to publish.
